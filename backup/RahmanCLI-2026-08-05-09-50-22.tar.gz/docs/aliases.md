# Rahman CLI Aliases


i=install
ins=install

n=new
newp=new

b=build
r=run

u=update

t=test

d=doctor
